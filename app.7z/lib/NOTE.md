NOTE

This work is based on a free local version of Font Awesome. More on [here](https://fontawesome.com/).

If you want, you may also apply for a CDN-based version!
